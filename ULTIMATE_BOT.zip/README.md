# ULTIMATE BOT - Telegram Mafia Game 🤵💎

## Qo‘llab-quvvatlanadigan tillar:
- 🇺🇿 O‘zbekcha
- 🇷🇺 Русский
- 🇬🇧 English

## Ishga tushirish:
```bash
pip install -r requirements.txt
python bot.py
```

## Heroku’da deploy qilish:
1. `heroku login`
2. `heroku create ultimate-bot`
3. `git push heroku main`
4. `heroku config:set TOKEN=your_token`
5. `heroku ps:scale worker=1`
