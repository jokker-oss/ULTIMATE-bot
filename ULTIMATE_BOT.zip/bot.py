import os
import telebot
from telebot.types import ReplyKeyboardMarkup

TOKEN = os.getenv("TOKEN", "8080400436:AAF5IZCZJ-WjbUuvJVo4dLS4jsmDxOm1TR8")
bot = telebot.TeleBot(TOKEN)

# Languages dictionary
languages = {
    'uz': {
        'start': "👋 Salom! ULTIMATE BOT Mafia o'yiniga xush kelibsiz!",
        'balance': "💰 Balansingiz: {money}$, Olmos: {diamonds}💎"
    },
    'ru': {
        'start': "👋 Привет! Добро пожаловать в мафию ULTIMATE BOT!",
        'balance': "💰 Ваш баланс: {money}$, Алмазы: {diamonds}💎"
    },
    'en': {
        'start': "👋 Hello! Welcome to ULTIMATE BOT Mafia game!",
        'balance': "💰 Your balance: {money}$, Diamonds: {diamonds}💎"
    }
}

# Simple user storage (in-memory)
users = {}

@bot.message_handler(commands=['start'])
def start(message):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add("🇺🇿 O'zbekcha", "🇷🇺 Русский", "🇬🇧 English")
    bot.send_message(message.chat.id, "Tilni tanlang / Выберите язык / Choose language:", reply_markup=markup)

@bot.message_handler(func=lambda m: m.text in ["🇺🇿 O'zbekcha", "🇷🇺 Русский", "🇬🇧 English"])
def set_language(message):
    lang = 'uz' if 'O'zbek' in message.text else 'ru' if 'Рус' in message.text else 'en'
    users[message.from_user.id] = {'lang': lang, 'money': 100, 'diamonds': 5}
    bot.send_message(message.chat.id, languages[lang]['start'])

@bot.message_handler(commands=['balance'])
def balance(message):
    user = users.get(message.from_user.id)
    if user:
        msg = languages[user['lang']]['balance'].format(money=user['money'], diamonds=user['diamonds'])
        bot.send_message(message.chat.id, msg)
    else:
        bot.send_message(message.chat.id, "❗Iltimos, avval /start buyrug'ini bering.")

bot.polling()
